<?php
namespace Plugins\MassVoting;
use dgr\nohup\Process;

require_once PLUGINS_PATH."/".IDNAME."/vendor/autoload.php";

// Disable direct access
if (!defined('APP_VERSION'))
    die("Yo, what's up?");

/**
 * Index Controller
 *
 * @version 1.0
 *
 *
 */
class IndexController extends \Controller
{
    /**
     * idname of the plugin for internal use
     */
    const IDNAME = 'massvoting';

    /**
     * Process
     */
    public function process()
    {
        $AuthUser = $this->getVariable("AuthUser");
        $this->setVariable("idname", self::IDNAME);

        // Auth
        if (!$AuthUser){
            header("Location: ".APPURL."/login");
            exit;
        } else if ($AuthUser->isExpired()) {
            header("Location: ".APPURL."/expired");
            exit;
        }

        $user_modules = $AuthUser->get("settings.modules");
        if (!is_array($user_modules) || !in_array(self::IDNAME, $user_modules)) {
            // Module is not accessible to this user
            header("Location: ".APPURL."/post");
            exit;
        }

        // Get accounts
        $Accounts = \Controller::model("Accounts");
        $Accounts->setPageSize(20)
                 ->setPage(\Input::get("page"))
                 ->where("user_id", "=", $AuthUser->get("id"));

        $search_query = \Input::get("q");
        if (!empty($search_query)) {
            $search_query = trim($search_query);
            $Accounts->where("username", "LIKE", $search_query."%");
        }

        $Accounts->orderBy("id","DESC")
                 ->fetchData();

        // Get schedules data
        if (\Input::get("page") == 0) {
            $sc_data = [];
        }

        require_once PLUGINS_PATH."/".$this->getVariable("idname")."/models/ScheduleModel.php";
        foreach ($Accounts->getDataAs("Account") as $a) {
            $sc = new ScheduleModel([
                "account_id" => $a->get("id"),
                "user_id" => $a->get("user_id")
            ]);

            $sc_data[$a->get("id")] = [
                "is_active" => $sc->get("is_active"),
                "estimated_speed" => $sc->get("data.estimated_speed")
            ];

            // Check is process really active or not
            $pid = $sc->get("process_id");
            $is_active = $sc->get("is_active");
            $is_running = $sc->get("is_running");
            $is_executed = $sc->get("is_executed");

            if ($pid && $is_active && $is_running && $is_executed) {
                $process = Process::loadFromPid($pid);
                if ($process->isRunning()) {
                    // All fine
                } else {
                    // Re-active process
                    // Process deactivated because of external factors or server reboot
                    $sc->set("process_id", 0)
                       ->set("is_running", 0)
                       ->set("is_executed", 0)
                       ->save();
                }
            }
        }

        if (\Input::post("action") == "update_data") {
            $this->update_data();
        }

        $this->setVariable("Accounts", $Accounts);
        $this->setVariable("sc_data", $sc_data);

        $this->view(PLUGINS_PATH."/".self::IDNAME."/views/index.php", null);
    }

    /**
     * Get selected schedule estimated speed
     * @return string
     */
    private function update_data()
    {
        $this->resp->result = 0;

        $AuthUser = $this->getVariable("AuthUser");

        if (!\Input::post("id")) {
            $this->resp->title = __("Error");
            $this->resp->msg = __("ID is requred!");
            $this->jsonecho();
        }

        $Account = \Controller::model("Account", \Input::post("id"));

        // Check Account ID and Account Status
        if (!$Account->isAvailable() ||
            $Account->get("user_id") != $AuthUser->get("id"))
        {
            $this->resp->title = __("Error");
            $this->resp->msg = __("Account does not exist or ID is invalid.");
            $this->jsonecho();
        }

        $Schedule = new ScheduleModel([
            "account_id" => $Account->get("id"),
            "user_id" => $AuthUser->get("id")
        ]);

        $this->resp->estimated_speed = $Schedule->get("data.estimated_speed") ? $Schedule->get("data.estimated_speed") : 0;
        $this->resp->is_active = $Schedule->get("is_active") ? $Schedule->get("is_active") : 0;

        $this->resp->result = 1;
        $this->jsonecho();
    }
}