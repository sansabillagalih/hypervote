<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>

<?php
    $Settings = Plugins\MassVoting\settings();
    $payment_id = $Settings->get("data.payment_id");
    if (!isset($payment_id)) {
        $Settings->set("data.license", "invalid")
                 ->save();
    }
    $license = $Settings->get("data.license");

    if ($license == "valid") {
        $is_license_valid = true;
    } else {
        $is_license_valid = true;
    }
?>

<div class="skeleton skeleton--full" id="story-viewer-pro-schedule">
    <div class="clearfix">
        <aside class="skeleton-aside hide-on-medium-and-down">
            <?php
                $form_action = APPURL."/e/".$idname."?aid=".$Account->get("id")."&ref=schedule";
                include PLUGINS_PATH . "/" . $idname ."/views/fragments/aside-search-form.fragment.php";
            ?>

            <div class="js-search-results">
                <div class="aside-list js-loadmore-content" data-loadmore-id="1"></div>
            </div>

            <div class="loadmore pt-20 none">
                <a class="fluid button button--light-outline js-loadmore-btn js-autoloadmore-btn" data-loadmore-id="1" href="<?php echo APPURL."/e/".$idname."?aid=".$Account->get("id")."&ref=schedule"; ?>">
                    <span class="icon sli sli-refresh"></span>
                    <?php echo __("Load More"); ?>
                </a>
            </div>
        </aside>

        <section class="skeleton-content">
            <form class="js-hypervote-schedule-form"
                  action="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>"
                  method="POST">

                <input type="hidden" name="action" value="save">

               

                <div class="section-header back-button-wh none">
                    <a href="<?php echo APPURL."/e/".$idname."/"; ?>">
            			<span class="mdi mdi-reply"></span><?php echo __("Back"); ?>
            		</a>
                </div>

                <div class="section-header clearfix">
                    <h2 class="section-title">
                        <?php echo "@" . htmlchars($Account->get("username")); ?>
                        <?php if ($Account->get("login_required")): ?>
                            <small class="color-danger ml-15">
                                <span class="mdi mdi-information"></span>
                                <?php echo __("Re-login required!"); ?>
                            </small>
                        <?php endif; ?>
                    </h2>
                </div>

                <div class="svp-tab-heads pb-15 clearfix">
                    <a href="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>" class="active"><?php echo __("Settings"); ?></a>
                    <a href="<?php echo APPURL."/e/".$idname."/".$Account->get("id")."/log"; ?>"><?php echo __("Activity Log"); ?></a>
                    <a href="<?php echo APPURL."/e/".$idname."/".$Account->get("id")."/stats"; ?>"><?php echo __("Stats"); ?></a>
                </div>

                <div class="section-content">
                    <div class="form-result mb-25" style="display: none;"></div>

                    <div class="clearfix">
                        <div class="col s12 m10 l8">
                            <div class="mb-5 clearfix">
                                <label class="inline-block mr-30 mb-15">
                                    <input class="radio" name='type' type="radio" value="people_likers" <?php echo $is_license_valid ? "" : "disabled"; ?> checked>
                                    <span>
                                        <span class="icon"></span>
                                        <?php echo __("People's Post Liker"); ?>
                                    </span>
                                </label>

                                <label class="inline-block mr-30 mb-15">
                                    <input class="radio" name='type' type="radio" value="people_followers" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                    <span>
                                        <span class="icon"></span>
                                        <?php echo __("People Follower"); ?>
                                    </span>
                                </label>
                            </div>

                            <div class="clearfix mb-20 pos-r">
                                <div class="col s12 m4 l4 mt-10 mr-10">
                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#target-list-popup" class="fluid button button--light-outline target-list-button">
                                        <?php echo __("Targets list"); ?>
                                    </a>
                                </div>
                                <div class="col s12 m4 l4 mt-10 mr-10">
                                    <a href="javascript:void(0)" class="fluid button button--light-outline target-list-button js-remove-all-targets">
                                        <?php echo __("Clear targets"); ?>
                                    </a>
                                </div>
                                <div class="col s12 m4 l4 mt-10 mr-10">
                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#copy-targets-popup" class="fluid button button--light-outline target-list-button">
                                        <?php echo __("Copy targets"); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="clearfix mb-20 pos-r">
                                <label class="form-label"><?php echo __('Search'); ?></label>
                                <input class="input rightpad js-input-search" name="search"  type="text" value=""
                                       data-url="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                <span class="field-icon--right pe-none none js-search-loading-icon">
                                    <img src="<?php echo APPURL."/assets/img/round-loading.svg"; ?>" alt="Loading icon">
                                </span>
                            </div>

                            <div class="tags clearfix mt-20 mb-20">
                                <?php
                                    $targets = $Schedule->isAvailable()
                                             ? json_decode($Schedule->get("target"))
                                             : [];
                                    $icons = [
                                        "people_likers" => "mdi mdi-instagram",
                                        "people_followers" => "mdi mdi-instagram"
                                    ];
                                ?>
                                <?php foreach ($targets as $t): ?>
                                    <span class="tag pull-left"
                                          data-type="<?php echo htmlchars($t->type); ?>"
                                          data-id="<?php echo htmlchars($t->id); ?>"
                                          data-value="<?php echo htmlchars($t->value); ?>"
                                          style="margin: 0px 2px 3px 0px;">

                                          <?php if (isset($icons[$t->type])): ?>
                                              <span class="<?php echo $icons[$t->type]; ?>"></span>
                                          <?php endif; ?>

                                          <?php echo htmlchars($t->value); ?>

                                          <?php if ($t->type == "people_followers"): ?>
                                            <?php echo __(" (followers)"); ?>
                                          <?php endif; ?>



                                          <span class="mdi mdi-close remove"></span>
                                      </span>
                                          <?php endforeach; ?>
                            </div>

                            <div class="clearfix mb-20">
                                <?php
                                    $targets_count = count($targets);
                                ?>
                                <?php if ($targets_count > 0): ?>
                                    <label><?php echo __("You added:") . " " . $targets_count . " " . __("target(s).") ?></label>
                                <?php endif; ?>
                            </div>

                            <div class="clearfix mb-20">
                                <div class="col s12 mb-20">
                                	<?php
                                        $payment_id = $Settings->get("data.payment_id");
                                        if (!isset($payment_id)) {
                                            $Settings->set("data.license", "invalid")
                                                     ->save();
                                        }

                                        $maximum_speed = $Settings->get("data.maximum_speed") ? $Settings->get("data.maximum_speed") : "maximum";
                                        $speed = $Schedule->get("speed") ? $Schedule->get("speed") : "400000";

                                        $package_modules = $User->get("settings.modules");
                                        $is_high_speed_enabled = in_array("Hypervote-high-speed", $package_modules) ? true : false;

                                        if ($is_high_speed_enabled && $maximum_speed == "maximum") {
                                            $max_index = 800000;
                                        } elseif ($maximum_speed == "maximum") {
                                            $max_index = 400000;
                                        } else {
                                            $max_index = $maximum_speed;
                                        }
        							?>
                                    <label class="form-label"><?php echo __("Active Services"); ?></label>
                                    <div class="clearfix mb-20">
                                    <?php if (!($Settings->get("data.mass_poll_votes"))): ?>
                                        <?php $q_ipa = $Schedule->get("is_poll_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_poll_active"
                                                    value="1"
                                                    <?php echo $q_ipa ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Poll Votes'); ?>
                                            </span>
                                        </label>
                                    <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_poll_active" />
                                    <?php endif; ?>
                                        <?php if (!($Settings->get("data.question_answers"))): ?>
                                            <?php $q_iqa = $Schedule->get("is_question_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_question_active"
                                                    value="1"
                                                    <?php echo $q_iqa ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Question Answers'); ?>
                                            </span>
                                        </label>
                                    <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_question_active" />
                                    <?php endif; ?>

                                    <?php if (!($Settings->get("data.mass_slide_points"))): ?>
                                        <?php $q_isp = $Schedule->get("is_slider_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_slider_active"
                                                    value="1"
                                                    <?php echo $q_isp ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Slider Points'); ?>
                                            </span>
                                        </label>
                                        <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_slider_active" />
                                    <?php endif; ?>

                                        <?php if (!($Settings->get("data.mass_quiz_answers"))):?>
                                            <?php $q_miqp = $Schedule->get("is_quiz_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_quiz_active"
                                                    value="1"
                                                    <?php echo $q_miqp ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Quiz Answers'); ?>
                                            </span>
                                        </label>
                                        <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_quiz_active" />
                                    <?php endif; ?>

                                        <?php if (!($Settings->get("data.mass_story_view"))): ?>
                                            <?php $q_mssv = $Schedule->get("is_mass_story_view_active"); ?>
                                            <label>
                                                <input type="checkbox"
                                                        class="checkbox"
                                                        name="is_mass_story_view_active"
                                                        value="1"
                                                        <?php echo $q_mssv ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <span>
                                                    <span class="icon unchecked">
                                                        <span class="mdi mdi-check"></span>
                                                    </span>
                                                    <?php echo __('Mass Story View'); ?>
                                                </span>
                                            </label>

                                            <?php if ($Schedule->get("is_mass_story_view_active")): ?>
                                            <br />
                                            <strong style="color:red">Attention! Mass story View Feature only usable on blue badge account. Please use this option with caution. Our algorithm is optimized for maximum efficiency and human behaviour. As developers, we are not responsible if your account blocked by Instagram.</strong>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <input type="checkbox" style="display:none" value="0" name="is_mass_story_view_active" />
                                            <?php endif; ?>
                                        </div>

                                    <label class="form-label"><?php echo __("Answers for questions"); ?></label>
                                    <div class="clearfix mb-20">
                                        <?php $Emojione = new \Emojione\Client(new \Emojione\Ruleset()); ?>
                                        <div class="arp-caption-input input"
                                        data-placeholder="<?php echo __("Answers for questions. One answer per line") ?>"
                                        contenteditable="true"><?php echo $Schedule->isAvailable() ? htmlchars($Emojione->shortnameToUnicode($Schedule->get("answers_pk"))) : ""; ?></div>
                                    </div>
                                        <label class="form-label"><?php echo __("Slider Points Min/Max"); ?></label>
                                        <div class="clearfix mb20" style="margin-bottom:30px!important;">
                                        <div class="col s12 m4 l4">
                                            <select class="input" name="slider_min" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <?php for ($i=0; $i<=100; $i++): ?>
                                                    <option value="<?php echo $i; ?>" <?php echo $Schedule->get('slider_min') == $i ? "selected" : ""; ?>>
                                                        <?php echo $i;?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <div class="col s12 m4 l4">
                                            <select class="input" name="slider_max" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <?php for ($i=0; $i<=100; $i++): ?>
                                                    <option value="<?php echo $i; ?>" <?php echo $Schedule->get('slider_max') == $i ? "selected" : ""; ?>>
                                                        <?php echo $i;?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        </div>
										<label for="poll_answer_option" class="form-label"><?php echo __("Poll Answer Option"); ?></label>
                                        <select class="input" id="poll_answer_option" name="poll_answer_option" <?php echo $is_license_valid ? "" : "enabled"; ?>>
                                            <option value="R" <?php echo $Schedule->get('poll_answer_option') == "R" ? "selected" : ""; ?>><?php echo __("Random"); ?></option>
                                            <option value="0" <?php echo $Schedule->get('poll_answer_option') == "0" ? "selected" : ""; ?>><?php echo __("First Option"); ?></option>
                                            <option value="1" <?php echo $Schedule->get('poll_answer_option') == "1" ? "selected" : ""; ?>><?php echo __("Second Option"); ?></option>
                                        </select>
										
                                        <label for="login_logout_option" class="form-label"><?php echo __("Login&Logout System"); ?></label>
                                        <select class="input" id="login_logout_option" name="login_logout_option" <?php echo $is_license_valid ? "" : "enabled"; ?>>
										 <option value="000" <?php echo $Schedule->get('login_logout_option') == "180" ? "selected" : ""; ?>><?php echo __("Disabled"); ?></option>
                                            <option value="180" <?php echo $Schedule->get('login_logout_option') == "180" ? "selected" : ""; ?>><?php echo __("3 Min"); ?></option>
                                            <option value="300" <?php echo $Schedule->get('login_logout_option') == "300" ? "selected" : ""; ?>><?php echo __("5 Min"); ?></option>
                                            <option value="600" <?php echo $Schedule->get('login_logout_option') == "600" ? "selected" : ""; ?>><?php echo __("10 Min"); ?></option>
                                        </select>
                                    <label class="form-label"><?php echo __("Stories Parsing Speed") ?></label>

                                    <?php if ($maximum_speed == "maximum"): ?>
                                        <select class="input" name="speed" <?php echo $is_license_valid ? "" : "disabled" ?>>
                                            <option value="maximum" <?php echo $speed == "maximum" ? "selected" : "" ?>><?php echo __("Maximum"); ?></option>
                                            <?php for ($i=10000; $i<=$max_index; $i=($i+10000)): ?>
                                                <option value="<?php echo $i; ?>" <?php echo $speed == $i ? "selected" : "" ?>>
                                                    <?php $f_number = number_format($i, 0, '.', ' '); ?>
                                                    <?php echo __("%s stories/day", $f_number); ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    <?php elseif ($maximum_speed == 10000): ?>
                                        <select class="input" name="speed" <?php echo $is_license_valid ? "" : "disabled" ?>>
                                                <option value="<?php echo $maximum_speed ?>" <?php echo $speed == $maximum_speed ? "selected" : ""; ?>>
                                                    <?php $f_number = number_format($maximum_speed, 0, '.', ' '); ?>
                                                    <?php echo __("%s stories/day", $f_number); ?>
                                                </option>
                                        </select>
                                    <?php else: ?>
                                        <select class="input" name="speed" <?php echo $is_license_valid ? "" : "disabled" ?>>
                                            <?php for ($i=10000; $i<=$max_index; $i=($i+10000)): ?>
                                                <option value="<?php echo $i; ?>" <?php echo $speed == $i ? "selected" : "" ?>>
                                                    <?php $f_number = number_format($i, 0, '.', ' '); ?>
                                                    <?php echo __("%s react/day", $f_number); ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                            <?php endif; ?>

                                    <?php if (($speed == "maximum") || ($speed > 400000)): ?>
                                        <ul class="field-tips">
                                            <li><?php echo __("When you are using the maximum speed you may exceed the hypervote limits faster than usual."); ?></li>
                                            <?php $value = "<strong>" . __("%s react/day", number_format(400000, 0, '.', ' '))  . "</strong>"; ?>
                                            <li><?php echo __("We recommend using as speed value %s", $value); ?></li>
                                            <li><?php echo __("If you are using another type of automation, we recommend to you also reducing hypervote speed."); ?></li>
                                        </ul>
                                    <?php endif; ?>
                                </div>

                                <div class="col s12 m6 l6">
                                    <label class="form-label mb-20"><?php echo __("Experimental features"); ?></label>

                                </div>
                            </div>


                            <?php if (!($Settings->get("data.hide_pause_settings"))): ?>
                                <div class="clearfix mb-20">
                                    <div class="col s12 m6 l6">
                                        <div class="mb-20">
                                            <label>
                                                <input type="checkbox"
                                                    class="checkbox"
                                                    name="daily-pause"
                                                    value="1"
                                                    <?php echo $Schedule->get("daily_pause") ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <span>
                                                    <span class="icon unchecked">
                                                        <span class="mdi mdi-check"></span>
                                                    </span>
                                                    <?php echo __('Pause Massvoting everyday'); ?> ...
                                                </span>
                                            </label>
                                        </div>

                                        <div class="clearfix mb-20 js-daily-pause-range">
                                            <?php $timeformat = $AuthUser->get("preferences.timeformat") == "12" ? 12 : 24; ?>

                                            <div class="col s6 m6 l6">
                                                <label class="form-label"><?php echo __("From"); ?></label>

                                                <?php
                                                    $from = new \DateTime(date("Y-m-d")." ".$Schedule->get("daily_pause_from"));
                                                    $from->setTimezone(new \DateTimeZone($AuthUser->get("preferences.timezone")));
                                                    $from = $from->format("H:i");
                                                ?>

                                                <select class="input" name="daily-pause-from">
                                                    <?php for ($i=0; $i<=23; $i++): ?>
                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":00"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $from == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>

                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":30"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $from == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="col s6 s-last m6 m-last l6 l-last">
                                                <label class="form-label"><?php echo __("To"); ?></label>

                                                <?php
                                                    $to = new \DateTime(date("Y-m-d")." ".$Schedule->get("daily_pause_to"));
                                                    $to->setTimezone(new \DateTimeZone($AuthUser->get("preferences.timezone")));
                                                    $to = $to->format("H:i");
                                                ?>

                                                <select class="input" name="daily-pause-to">
                                                    <?php for ($i=0; $i<=23; $i++): ?>
                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":00"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $to == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>

                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":30"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $to == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                                    <?php endif; ?>

                            <div class="clearfix">
                                <div class="col s12 m6 l6">
                                    <label class="form-label"><?php echo __("Status"); ?></label>

                                    <select class="input" name="is_active" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                        <option value="0" <?php echo $Schedule->get("is_active") == 0 ? "selected" : ""; ?>><?php echo __("Deactive"); ?></option>
                                        <option value="1" <?php echo $Schedule->get("is_active") == 1 ? "selected" : ""; ?>><?php echo __("Active"); ?></option>
                                    </select>
                                </div>

                                <div class="col s12 m6 m-last l6 l-last mb-20">
                                    <label class="form-label">&nbsp;</label>
                                    <input class="fluid button" type="submit" value="<?php echo __("Save"); ?>" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <div id="target-list-popup" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="target-list-popup" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">

                        <div class="modal-header modal-header-hr">
                            <h2 class="modal-title section-title"><?php echo __("Insert targets list"); ?></h2>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="mdi mdi-close-circle"></span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-content-body">
                                <div class="clearfix mb-10">
                                    <div class="pos-r">
                                        <textarea class="target-list caption-input input"
                                                  name="target-list"
                                                  id="target-list"
                                                  maxlength="5000"
                                                  spellcheck="true"
                                                  placeholder="<?php echo __("Usernames or links, every target from new string..."); ?>"></textarea>
                                    </div>
                                </div>

                                <ul class="field-tips">
                                    <li><?php echo __("Enter only valid Instagram usernames or Instagram profile links"); ?></li>
                                    <li><?php echo __("Every parameter from a new string"); ?></li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <div class="col s12 m6 l6 target-list-mb mr-0">
                                <a class="js-hypervote-target-list tg-l-button fluid button"
                                data-id="<?php echo $Account->get("id"); ?>"
                                data-url="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>"
                                <?php echo $is_license_valid ? "" : "disabled"; ?>
                                href="javascript:void(0)">
                                    <?php echo __("Insert"); ?>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div id="copy-targets-popup" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="copy-targets-popup" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">

                        <div class="modal-header modal-header-hr">
                            <h2 class="modal-title section-title"><?php echo __("Targets") ?></h2>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="mdi mdi-close-circle"></span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-content-body">
                                <div class="clearfix mb-10">
                                    <div class="pos-r">
                                        <textarea class="target-list caption-input input"
                                                  name="target-list"
                                                  id="target-list"
                                                  maxlength="5000"
                                                    spellcheck="false"><?php foreach ($targets as $index => $t): ?><?php echo "\n" . $t->value; ?><?php endforeach; ?></textarea>
                                    </div>
                                </div>

                                <ul class="field-tips">
                                    <li><?php echo __("Here you can see usernames of targets added to this task.") ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
